
selected_lang = None