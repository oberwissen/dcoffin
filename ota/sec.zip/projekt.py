
class general:
    name = "dcoffin"
    author = "oberwissen"
    version = "0.0.4 Alpha"

class oberwissen:
    master_engineer_name = "Yakup ASLANTAŞ"
    master_engineer_rank = "oberwissenführer"
    master_engineer_casual_dialog_rank = "führer"
    project_version_major = 0
    project_version_minor = 0
    project_version_patch = 4
    oberwissen_telegram_channel = "t.me/oberwissen"
    project_codename = "as-dc"
    project_common_name = "ApiStorm Project"
    project_generation = 1
    project_generation_casual = "1st Generation of ApiStorm dcoffin project"

class firmware_over_the_air:
    revision = 4







